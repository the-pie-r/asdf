<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/wazuh_api.php';
require_once __DIR__ . '/slack.php';

header('Content-Type: application/json');
if (!isLoggedIn()) { http_response_code(401); echo json_encode(['error'=>'Unauthorized']); exit(); }

$action   = $_GET['action'] ?? $_POST['action'] ?? '';
$settings = loadSettings();

function ok(array $d): void { echo json_encode($d); exit(); }
function fail(string $m, int $c=400): void { http_response_code($c); echo json_encode(['error'=>$m]); exit(); }

switch ($action) {

    case 'stats':
        try {
            $db = getDB();
            $total24  = (int)$db->query("SELECT COUNT(*) FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL 24 HOUR")->fetchColumn();
            $total1h  = (int)$db->query("SELECT COUNT(*) FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL 1 HOUR")->fetchColumn();
            $uniqueIPs= (int)$db->query("SELECT COUNT(DISTINCT src_ip) FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL 24 HOUR")->fetchColumn();
            $blocked  = (int)$db->query("SELECT COUNT(*) FROM blocked_ips WHERE is_active=1")->fetchColumn();
            $topIP    = $db->query("SELECT src_ip,COUNT(*) c FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL 24 HOUR GROUP BY src_ip ORDER BY c DESC LIMIT 1")->fetch();
        } catch(Exception $e){ $total24=$total1h=$uniqueIPs=$blocked=0; $topIP=null; }

        // Agents
        $wazuh   = new WazuhAPI($settings);
        $agents  = $wazuh->getAgents() ?? [];
        $online  = count(array_filter($agents, fn($a)=>($a['status']??'')==='active'));

        ok(['total_alerts'=>$total24,'alerts_1h'=>$total1h,'unique_ips'=>$uniqueIPs,
            'blocked_ips'=>$blocked,'agents_online'=>$online,'agents_total'=>count($agents),
            'top_ip'=>$topIP['src_ip']??null,'top_ip_count'=>$topIP['c']??0]);

    case 'alerts':
        $hours = min((int)($_GET['hours']??24),168);
        try {
            $stmt = getDB()->prepare("
                SELECT id,agent_name,src_ip,rule_id,rule_level,description,attack_type,timestamp,created_at
                FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL ? HOUR
                ORDER BY created_at DESC LIMIT 500");
            $stmt->execute([$hours]);
            $rows = $stmt->fetchAll();
        } catch(Exception $e){ $rows=[]; }
        ok(['alerts'=>$rows,'count'=>count($rows)]);

    case 'timeline':
        try {
            $rows = getDB()->query("
                SELECT DATE_FORMAT(created_at,'%Y-%m-%d %H:00:00') AS h, COUNT(*) c
                FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL 24 HOUR
                GROUP BY h ORDER BY h")->fetchAll();
        } catch(Exception $e){ $rows=[]; }
        ok(['timeline'=>$rows]);

    case 'attack_types':
        try {
            $rows = getDB()->query("
                SELECT attack_type, COUNT(*) cnt FROM brute_force_alerts
                WHERE created_at>=NOW()-INTERVAL 24 HOUR GROUP BY attack_type ORDER BY cnt DESC")->fetchAll();
        } catch(Exception $e){ $rows=[]; }
        ok(['types'=>$rows]);

    case 'top_ips':
        try {
            $rows = getDB()->query("
                SELECT src_ip, COUNT(*) cnt, MAX(created_at) last_seen
                FROM brute_force_alerts WHERE created_at>=NOW()-INTERVAL 24 HOUR
                GROUP BY src_ip ORDER BY cnt DESC LIMIT 10")->fetchAll();
        } catch(Exception $e){ $rows=[]; }
        ok(['ips'=>$rows]);

    case 'agents':
        $wazuh = new WazuhAPI($settings);
        ok(['agents'=>$wazuh->getAgents()??[]]);

    case 'blocked_ips':
        try {
            $rows = getDB()->query("
                SELECT ip_address,blocked_at,reason,agent_name FROM blocked_ips
                WHERE is_active=1 ORDER BY blocked_at DESC LIMIT 200")->fetchAll();
        } catch(Exception $e){ $rows=[]; }
        ok(['blocked'=>$rows,'count'=>count($rows)]);

    case 'block_ip':
        $ip  = filter_var($_POST['ip']??'', FILTER_VALIDATE_IP);
        if (!$ip) fail('Invalid IP');
        // Try iptables direct
        $escaped = escapeshellarg($ip);
        exec("sudo iptables -I INPUT -s {$escaped} -j DROP 2>&1", $o, $rc);
        $ok = ($rc===0);
        if ($ok) {
            try {
                getDB()->prepare("INSERT INTO blocked_ips(ip_address,reason,agent_name,blocked_at,is_active)
                    VALUES(?,?,?,NOW(),1) ON DUPLICATE KEY UPDATE is_active=1,blocked_at=NOW()")
                       ->execute([$ip,'Manual block via SentinelWatch','dashboard']);
            } catch(Exception $e){}
        }
        ok(['success'=>$ok,'ip'=>$ip,'msg'=>implode("\n",$o)]);

    case 'unblock_ip':
        $ip = filter_var($_POST['ip']??'', FILTER_VALIDATE_IP);
        if (!$ip) fail('Invalid IP');
        $escaped = escapeshellarg($ip);
        exec("sudo iptables -D INPUT -s {$escaped} -j DROP 2>&1", $o, $rc);
        try { getDB()->prepare("UPDATE blocked_ips SET is_active=0 WHERE ip_address=?")->execute([$ip]); } catch(Exception $e){}
        ok(['success'=>true,'ip'=>$ip]);

    case 'slack_test':
        $slack = new SlackNotifier($settings);
        ok(['success'=>$slack->sendTest()]);

    case 'save_settings':
        $allowed=['wazuh_ip','wazuh_port','wazuh_user','wazuh_pass','slack_webhook','slack_channel','slack_level','block_threshold','block_duration','auto_block'];
        try {
            $db = getDB();
            foreach ($_POST as $k=>$v) {
                if (!in_array($k,$allowed)) continue;
                $db->prepare("INSERT INTO dashboard_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")
                   ->execute([$k,$v]);
            }
        } catch(Exception $e){ fail('Save failed: '.$e->getMessage()); }
        ok(['success'=>true]);

    case 'test_wazuh':
        $wazuh = new WazuhAPI($settings);
        $ok2   = $wazuh->testConnection();
        ok(['connected'=>$ok2,'info'=>$ok2?$wazuh->getManagerInfo():null]);

    case 'slack_log':
        try {
            $rows = getDB()->query("SELECT payload,response,success,created_at FROM slack_log ORDER BY created_at DESC LIMIT 30")->fetchAll();
        } catch(Exception $e){ $rows=[]; }
        ok(['log'=>$rows]);

    case 'run_cron':
        // Manually trigger cron from dashboard
        $out = shell_exec('sudo /usr/bin/php ' . __DIR__ . '/cron_alerts.php 2>&1');
        ok(['output'=>$out]);

    default: fail('Unknown action',404);
}
