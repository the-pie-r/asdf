<?php
function isLoggedIn(): bool {
    return !empty($_SESSION['user_id']);
}
function login(string $u, string $p): bool {
    try {
        $stmt = getDB()->prepare("SELECT id,username,password_hash FROM dashboard_users WHERE username=? AND is_active=1");
        $stmt->execute([$u]);
        $user = $stmt->fetch();
        if ($user && password_verify($p, $user['password_hash'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            return true;
        }
    } catch (Exception $e) { error_log($e->getMessage()); }
    return false;
}
