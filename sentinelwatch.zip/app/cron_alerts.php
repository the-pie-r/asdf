#!/usr/bin/env php
<?php
/**
 * SentinelWatch — Alert Sync Cron
 * Reads DIRECTLY from /var/ossec/logs/alerts/alerts.json (most reliable)
 * Also pulls blocked IPs from iptables so dashboard always stays in sync.
 *
 * Crontab (run as root):
 *   * * * * * /usr/bin/php /var/www/html/wazuh-dashboard/cron_alerts.php >> /var/log/sentinel-cron.log 2>&1
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/wazuh_api.php';
require_once __DIR__ . '/slack.php';

$startTime = microtime(true);
echo "[" . date('Y-m-d H:i:s') . "] SentinelWatch cron starting...\n";

$settings        = loadSettings();
$slack           = new SlackNotifier($settings);
$db              = getDB();
$SLACK_LEVEL     = (int)($settings['slack_level']     ?? 10);
$BLOCK_THRESHOLD = (int)($settings['block_threshold'] ?? 5);
$AUTO_BLOCK      = ($settings['auto_block'] ?? '1') === '1';

// ── BRUTE FORCE RULE IDs (Wazuh default + custom) ──────────────────
$BF_RULES = ['5503','5710','5711','5712','5716','5720','5758','5760','5763','5764','100002'];
// Also catch by group name / keywords
$BF_KEYWORDS = ['brute','authentication fail','multiple auth','sshd','invalid user','failed password'];

$newAlerts   = 0;
$slackSent   = 0;
$autoBlocked = [];

// ── METHOD 1: Read from alerts.json directly ───────────────────────
$alertsFile = '/var/ossec/logs/alerts/alerts.json';
if (!file_exists($alertsFile)) {
    echo "[WARN] alerts.json not found at {$alertsFile}\n";
    goto sync_iptables;
}

// Read last 500 lines efficiently
$lines = [];
$fh = fopen($alertsFile, 'r');
if ($fh) {
    // Use tail equivalent: seek near end
    fseek($fh, -min(filesize($alertsFile), 2*1024*1024), SEEK_END);
    fgets($fh); // discard partial first line
    while (!feof($fh)) {
        $line = fgets($fh);
        if ($line !== false && trim($line) !== '') $lines[] = trim($line);
    }
    fclose($fh);
}

echo "[INFO] Read " . count($lines) . " log lines\n";

foreach ($lines as $line) {
    $a = json_decode($line, true);
    if (!$a || !isset($a['rule'])) continue;

    $ruleId    = (string)($a['rule']['id']          ?? '');
    $ruleLevel = (int)   ($a['rule']['level']        ?? 0);
    $groups    = implode(',', (array)($a['rule']['groups'] ?? []));
    $desc      = $a['rule']['description']           ?? '';
    $srcIp     = $a['data']['srcip']                 ?? $a['data']['src_ip'] ?? '';
    $agentId   = $a['agent']['id']                   ?? '000';
    $agentName = $a['agent']['name']                 ?? 'manager';
    $ts        = $a['timestamp']                     ?? date('Y-m-d\TH:i:s\Z');

    // Filter: only brute-force events
    $isBF = in_array($ruleId, $BF_RULES);
    if (!$isBF) {
        $descLower = strtolower($desc . ' ' . $groups);
        foreach ($BF_KEYWORDS as $kw) {
            if (strpos($descLower, $kw) !== false && $ruleLevel >= 5) { $isBF = true; break; }
        }
    }
    if (!$isBF || empty($srcIp)) continue;

    // Parse timestamp
    $tsMySQL = date('Y-m-d H:i:s', strtotime($ts));
    // Skip if older than 5 minutes (already processed)
    if (strtotime($tsMySQL) < time() - 300) continue;

    // Determine type
    $attackType = 'SSH Brute Force';
    if (stripos($desc,'ftp')!==false)    $attackType = 'FTP Brute Force';
    if (stripos($desc,'rdp')!==false)    $attackType = 'RDP Brute Force';
    if (stripos($desc,'web')!==false)    $attackType = 'Web Brute Force';
    if (stripos($desc,'smtp')!==false)   $attackType = 'SMTP Brute Force';
    if (stripos($desc,'mysql')!==false)  $attackType = 'MySQL Brute Force';

    // Insert (unique on agent+ip+rule+minute to avoid duplicates)
    try {
        $minuteBucket = date('Y-m-d H:i', strtotime($tsMySQL));
        // Check if already stored this event
        $exists = $db->prepare("
            SELECT id FROM brute_force_alerts
            WHERE src_ip=? AND rule_id=? AND DATE_FORMAT(timestamp,'%Y-%m-%d %H:%i')=?
            LIMIT 1");
        $exists->execute([$srcIp, $ruleId, $minuteBucket]);
        if ($exists->fetch()) continue;

        $db->prepare("
            INSERT INTO brute_force_alerts
              (agent_id,agent_name,src_ip,rule_id,rule_level,description,attack_type,raw_log,timestamp,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([$agentId,$agentName,$srcIp,$ruleId,$ruleLevel,$desc,$attackType,
                      json_encode($a),$tsMySQL]);
        $newAlerts++;
    } catch (Exception $e) {
        echo "[WARN] Insert error: " . $e->getMessage() . "\n";
        continue;
    }

    // Slack notification
    if ($ruleLevel >= $SLACK_LEVEL) {
        if ($slack->sendAlert([
            'src_ip'=>$srcIp,'agent_name'=>$agentName,'rule_id'=>$ruleId,
            'rule_level'=>$ruleLevel,'description'=>$desc,'attack_type'=>$attackType,
            'timestamp'=>$ts
        ])) $slackSent++;
    }

    // Auto-block check
    if ($AUTO_BLOCK && !isset($autoBlocked[$srcIp])) {
        $cnt = $db->prepare("
            SELECT COUNT(*) FROM brute_force_alerts
            WHERE src_ip=? AND created_at >= NOW() - INTERVAL 10 MINUTE");
        $cnt->execute([$srcIp]);
        $attempts = (int)$cnt->fetchColumn();

        if ($attempts >= $BLOCK_THRESHOLD) {
            $already = $db->prepare("SELECT id FROM blocked_ips WHERE ip_address=? AND is_active=1");
            $already->execute([$srcIp]);
            if (!$already->fetch()) {
                // Block via iptables directly (most reliable)
                $escaped = escapeshellarg($srcIp);
                exec("sudo iptables -I INPUT -s {$escaped} -j DROP 2>&1", $out, $rc);
                $blocked = ($rc === 0);

                if ($blocked) {
                    $db->prepare("
                        INSERT INTO blocked_ips(ip_address,reason,agent_name,blocked_at,is_active)
                        VALUES(?,?,?,NOW(),1)
                        ON DUPLICATE KEY UPDATE is_active=1,blocked_at=NOW(),reason=VALUES(reason)")
                       ->execute([$srcIp,"Auto-blocked: {$attempts} attempts in 10min",$agentName]);
                    $autoBlocked[$srcIp] = true;
                    echo "[BLOCK] {$srcIp} blocked ({$attempts} attempts)\n";
                    $slack->sendBlockNotice($srcIp, $attempts, $agentName);
                }
            }
        }
    }
}

// ── METHOD 2: Sync iptables blocks → DB ───────────────────────────
sync_iptables:
// Pull all currently blocked IPs from iptables and make sure they're in DB
exec("sudo iptables -L INPUT -n 2>/dev/null | grep -oP '(?<=s )[\d.]+' | sort -u", $iptablesIPs, $rc);
if ($rc === 0 && !empty($iptablesIPs)) {
    foreach ($iptablesIPs as $ip) {
        $ip = trim($ip);
        if (empty($ip) || $ip === '0.0.0.0') continue;
        try {
            $db->prepare("
                INSERT INTO blocked_ips(ip_address,reason,agent_name,blocked_at,is_active)
                VALUES(?,?,?,NOW(),1)
                ON DUPLICATE KEY UPDATE is_active=1")
               ->execute([$ip,'Detected from iptables','system']);
        } catch(Exception $e){}
    }
    echo "[SYNC] Synced " . count($iptablesIPs) . " iptables rules to DB\n";
}

// ── Cleanup: mark unblocked IPs ───────────────────────────────────
if (!empty($iptablesIPs)) {
    $placeholders = implode(',', array_fill(0, count($iptablesIPs), '?'));
    $db->prepare("UPDATE blocked_ips SET is_active=0 WHERE ip_address NOT IN ({$placeholders}) AND is_active=1")
       ->execute($iptablesIPs);
}

$elapsed = round(microtime(true) - $startTime, 2);
echo "[DONE] New alerts: {$newAlerts} | Slack: {$slackSent} | Blocked: " . count($autoBlocked) . " | {$elapsed}s\n";
