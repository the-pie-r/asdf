// SentinelWatch — dashboard.js
const API = 'api.php';
let tChart = null, typeChart = null, refreshTimer = null;

// ── Navigation ──────────────────────────────────────────────────
function showSection(name) {
    document.querySelectorAll('.sw-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(a => a.classList.remove('active'));
    document.getElementById('section-' + name)?.classList.add('active');
    document.querySelector(`.nav-item[onclick*="'${name}'"]`)?.classList.add('active');
    if (name === 'overview')  refreshAll();
    if (name === 'alerts')    loadAlerts();
    if (name === 'blocked')   loadBlocked();
    if (name === 'agents')    loadAgents();
    if (name === 'slack')     loadSlackLog();
}

// ── Core refresh ────────────────────────────────────────────────
async function refreshAll() {
    await Promise.all([loadStats(), loadRecentAlerts(), loadTimeline(), loadTypes(), loadTopIPs()]);
    document.getElementById('last-update').textContent = 'Updated ' + new Date().toLocaleTimeString();
}

// ── Stats ────────────────────────────────────────────────────────
async function loadStats() {
    const d = await get('stats');
    if (!d) return;
    ani('s-total',    d.total_alerts);
    ani('s-ips',      d.unique_ips);
    ani('s-agents',   d.agents_online);
    ani('s-blocked',  d.blocked_ips);
    document.getElementById('s-agents-sub').textContent = `${d.agents_online} of ${d.agents_total} connected`;
    document.getElementById('nav-alert-count').textContent  = d.total_alerts;
    document.getElementById('nav-blocked-count').textContent = d.blocked_ips;
    if (d.top_ip) {
        document.getElementById('s-total-sub').textContent = `Top: ${d.top_ip} (${d.top_ip_count}x)`;
    }
}

function ani(id, val) {
    const el = document.getElementById(id);
    if (!el) return;
    const target = parseInt(val) || 0;
    const current = parseInt(el.textContent) || 0;
    if (current === target) { el.textContent = target; return; }
    const step = Math.ceil(Math.abs(target - current) / 20);
    let v = current;
    const t = setInterval(() => {
        v = v < target ? Math.min(v + step, target) : Math.max(v - step, target);
        el.textContent = v;
        if (v === target) clearInterval(t);
    }, 30);
}

// ── Recent alerts (overview) ─────────────────────────────────────
async function loadRecentAlerts() {
    const d = await get('alerts', {hours: 24});
    if (!d) return;
    document.getElementById('recent-count').textContent = d.count;
    const tbody = document.getElementById('recent-tbody');
    if (!d.alerts.length) {
        tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><i class="fas fa-check-circle" style="color:#4ade80"></i>No brute force alerts in the last 24h</div></td></tr>`;
        return;
    }
    tbody.innerHTML = d.alerts.slice(0, 25).map(a => `
        <tr>
            <td style="white-space:nowrap;color:var(--muted);font-size:.78rem">${fmtTime(a.created_at)}</td>
            <td><span class="ip-tag">${esc(a.src_ip)}</span></td>
            <td><span class="agent-tag">${esc(a.agent_name)}</span></td>
            <td>${levelPill(a.rule_level)}</td>
            <td style="max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.8rem">${esc(a.description)}</td>
            <td><button class="btn-sm-red" onclick="blockIP('${a.src_ip}')"><i class="fas fa-ban"></i></button></td>
        </tr>`).join('');
}

// ── All alerts ───────────────────────────────────────────────────
async function loadAlerts() {
    const hours = document.getElementById('alert-hours')?.value ?? 24;
    const d = await get('alerts', {hours});
    if (!d) return;
    const tbody = document.getElementById('all-alerts-tbody');
    if (!d.alerts.length) {
        tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><i class="fas fa-check-circle" style="color:#4ade80"></i>No alerts found</div></td></tr>`;
        return;
    }
    tbody.innerHTML = d.alerts.map(a => `
        <tr>
            <td style="white-space:nowrap;color:var(--muted);font-size:.78rem">${fmtTime(a.created_at)}</td>
            <td><span class="ip-tag">${esc(a.src_ip)}</span></td>
            <td><span class="agent-tag">${esc(a.agent_name)}</span></td>
            <td><code style="color:var(--muted);font-size:.78rem">${esc(a.rule_id)}</code></td>
            <td>${levelPill(a.rule_level)}</td>
            <td style="font-size:.78rem;color:var(--muted)">${esc(a.attack_type)}</td>
            <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.78rem">${esc(a.description)}</td>
            <td style="white-space:nowrap">
                <button class="btn-sm-red me-1" onclick="blockIP('${a.src_ip}')"><i class="fas fa-ban me-1"></i>Block</button>
            </td>
        </tr>`).join('');
}

// ── Timeline chart ────────────────────────────────────────────────
async function loadTimeline() {
    const d = await get('timeline');
    if (!d?.timeline) return;
    const labels = d.timeline.map(r => r.h.substring(11, 16));
    const counts = d.timeline.map(r => parseInt(r.c));
    if (tChart) tChart.destroy();
    const ctx = document.getElementById('timelineChart')?.getContext('2d');
    if (!ctx) return;
    tChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                data: counts,
                borderColor: '#dc2626',
                backgroundColor: 'rgba(220,38,38,0.08)',
                fill: true, tension: 0.4, pointRadius: 3, pointBackgroundColor: '#dc2626',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: 'rgba(255,255,255,.05)' }, ticks: { color: '#64748b', font:{size:11} } },
                y: { grid: { color: 'rgba(255,255,255,.05)' }, ticks: { color: '#64748b', stepSize: 1 }, beginAtZero: true }
            }
        }
    });
}

// ── Attack type donut ─────────────────────────────────────────────
async function loadTypes() {
    const d = await get('attack_types');
    if (!d?.types?.length) return;
    const colors = ['#dc2626','#ea580c','#d97706','#2563eb','#7c3aed','#0891b2'];
    if (typeChart) typeChart.destroy();
    const ctx = document.getElementById('typeChart')?.getContext('2d');
    if (!ctx) return;
    typeChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: d.types.map(r => r.attack_type || 'Unknown'),
            datasets: [{
                data: d.types.map(r => r.cnt),
                backgroundColor: colors,
                borderWidth: 0, hoverOffset: 6
            }]
        },
        options: {
            responsive: true, cutout: '65%',
            plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', font:{size:11}, padding:10, boxWidth:10 } } }
        }
    });
}

// ── Top IPs ───────────────────────────────────────────────────────
async function loadTopIPs() {
    const d = await get('top_ips');
    if (!d?.ips) return;
    const el = document.getElementById('top-ips-list');
    if (!d.ips.length) {
        el.innerHTML = '<div class="empty-state" style="padding:20px"><i class="fas fa-check-circle" style="color:#4ade80;font-size:1.5rem"></i><div style="margin-top:8px;font-size:.8rem">No attacks recorded</div></div>';
        return;
    }
    const max = parseInt(d.ips[0]?.cnt) || 1;
    el.innerHTML = d.ips.map(ip => `
        <div class="top-ip-bar">
            <code class="mini">${esc(ip.src_ip)}</code>
            <div style="flex:1">
                <div class="sw-bar-track"><div class="sw-bar-fill" style="width:${Math.round(ip.cnt/max*100)}%"></div></div>
            </div>
            <span style="color:var(--accent);font-weight:700;font-size:.82rem;min-width:28px;text-align:right">${ip.cnt}</span>
            <button class="btn-sm-red" style="padding:3px 8px;font-size:.7rem" onclick="blockIP('${ip.src_ip}')"><i class="fas fa-ban"></i></button>
        </div>`).join('');
}

// ── Blocked IPs ───────────────────────────────────────────────────
async function loadBlocked() {
    const d = await get('blocked_ips');
    if (!d) return;
    document.getElementById('nav-blocked-count').textContent = d.count;
    const tbody = document.getElementById('blocked-tbody');
    if (!d.blocked.length) {
        tbody.innerHTML = `<tr><td colspan="5"><div class="empty-state"><i class="fas fa-check-circle" style="color:#4ade80"></i>No IPs currently blocked</div></td></tr>`;
        return;
    }
    tbody.innerHTML = d.blocked.map(b => `
        <tr>
            <td><span class="ip-tag">${esc(b.ip_address)}</span></td>
            <td style="color:var(--muted);font-size:.78rem">${fmtTime(b.blocked_at)}</td>
            <td style="font-size:.8rem;max-width:260px">${esc(b.reason)}</td>
            <td><span class="agent-tag">${esc(b.agent_name)}</span></td>
            <td><button class="btn-sm-green" onclick="unblockIP('${b.ip_address}')"><i class="fas fa-unlock me-1"></i>Unblock</button></td>
        </tr>`).join('');
}

// ── Agents ────────────────────────────────────────────────────────
async function loadAgents() {
    const d = await get('agents');
    const grid = document.getElementById('agents-grid');
    if (!d?.agents?.length) {
        grid.innerHTML = '<div class="col-12"><div class="empty-state"><i class="fas fa-server"></i>No agents found</div></div>';
        return;
    }
    const statusIcon = s => ({active:'dot-active',disconnected:'dot-disco',pending:'dot-pend','never_connected':'dot-never'})[s]||'dot-never';
    grid.innerHTML = d.agents.map(a => `
        <div class="col-md-4 col-lg-3">
            <div class="agent-card">
                <div class="agent-status">
                    <span class="dot ${statusIcon(a.status)}"></span>
                    <span style="text-transform:capitalize">${a.status?.replace('_',' ')}</span>
                    <span style="margin-left:auto;background:rgba(255,255,255,.06);padding:2px 8px;border-radius:6px;font-size:.72rem;color:var(--muted)">${a.id}</span>
                </div>
                <div class="agent-name">${esc(a.name)}</div>
                <div class="agent-meta">
                    <div><i class="fas fa-network-wired" style="width:14px;margin-right:5px;color:var(--muted)"></i>${esc(a.ip||'N/A')}</div>
                    <div><i class="fas fa-display" style="width:14px;margin-right:5px;color:var(--muted)"></i>${esc(a.os?.name||'Unknown OS')}</div>
                    <div><i class="fas fa-code-branch" style="width:14px;margin-right:5px;color:var(--muted)"></i>v${esc(a.version||'?')}</div>
                </div>
            </div>
        </div>`).join('');
}

// ── Slack ─────────────────────────────────────────────────────────
async function loadSlackLog() {
    const d = await get('slack_log');
    const el = document.getElementById('slack-log-body');
    if (!d?.log?.length) { el.innerHTML = '<div class="empty-state" style="padding:24px"><i class="fas fa-bell-slash"></i>No notifications sent yet</div>'; return; }
    el.innerHTML = d.log.map(l => {
        const p = JSON.parse(l.payload||'{}');
        const msg = p.text || p.attachments?.[0]?.pretext || 'Notification';
        const cls = l.success ? 'ok' : 'fail';
        const icon = l.success ? '✅' : '❌';
        return `<div class="slack-entry ${cls}">
            <span class="slack-marker">${icon}</span>
            <span style="color:var(--muted);font-size:.75rem;margin-left:6px">${fmtTime(l.created_at)}</span>
            <div style="margin-top:4px;color:var(--text)">${esc(msg.replace(/[*_~]/g,''))}</div>
        </div>`;
    }).join('');
}

async function testSlack() {
    const d = await post('slack_test', {});
    toast(d?.success ? 'success' : 'danger', d?.success ? '✅ Test message sent to Slack!' : '❌ Slack test failed — check webhook URL');
}

async function saveSlack() {
    const d = await post('save_settings', {
        slack_webhook: document.getElementById('slack-webhook').value,
        slack_channel: document.getElementById('slack-channel').value,
        slack_level:   document.getElementById('slack-level').value,
    });
    toast(d?.success ? 'success' : 'danger', d?.success ? 'Slack settings saved' : 'Save failed');
}

// ── Settings ──────────────────────────────────────────────────────
async function saveWazuh() {
    const d = await post('save_settings', {
        wazuh_ip:   document.getElementById('wazuh-ip').value,
        wazuh_port: document.getElementById('wazuh-port').value,
        wazuh_user: document.getElementById('wazuh-user').value,
        wazuh_pass: document.getElementById('wazuh-pass').value,
    });
    toast(d?.success ? 'success' : 'danger', d?.success ? 'Wazuh settings saved' : 'Save failed');
}

async function testWazuh() {
    toast('info', 'Testing Wazuh connection...');
    const d = await get('test_wazuh');
    const ver = d?.info?.data?.version ?? '?';
    toast(d?.connected ? 'success' : 'danger',
          d?.connected ? `✅ Connected! Manager v${ver}` : '❌ Connection failed — check IP/credentials');
}

async function saveBlock() {
    const d = await post('save_settings', {
        block_threshold: document.getElementById('block-threshold').value,
        block_duration:  document.getElementById('block-duration').value,
        auto_block:      document.getElementById('auto-block').checked ? '1' : '0',
    });
    toast(d?.success ? 'success' : 'danger', d?.success ? 'Auto-block settings saved' : 'Save failed');
}

// ── Block / Unblock ───────────────────────────────────────────────
async function blockIP(ip) {
    if (!confirm(`Block IP ${ip}?\n\nThis adds an iptables DROP rule immediately.`)) return;
    const d = await post('block_ip', {ip});
    if (d?.success) {
        toast('success', `🚫 ${ip} blocked`);
        loadBlocked(); loadStats();
    } else {
        toast('danger', `Failed to block ${ip}: ${d?.msg||'unknown error'}`);
    }
}

async function unblockIP(ip) {
    if (!confirm(`Unblock ${ip}?`)) return;
    const d = await post('unblock_ip', {ip});
    if (d?.success) { toast('success', `✅ ${ip} unblocked`); loadBlocked(); loadStats(); }
}

// ── Force cron sync ───────────────────────────────────────────────
async function runCron() {
    toast('info', '⏳ Running sync...');
    const d = await get('run_cron');
    const lines = (d?.output||'').trim().split('\n').slice(-3).join(' | ');
    toast('success', '✅ Sync done: ' + (lines||'complete'));
    refreshAll();
}

// ── Helpers ───────────────────────────────────────────────────────
async function get(action, params = {}) {
    try {
        const qs = new URLSearchParams({action, ...params}).toString();
        const r = await fetch(`${API}?${qs}`);
        return r.ok ? r.json() : null;
    } catch(e) { return null; }
}

async function post(action, params = {}) {
    try {
        const fd = new FormData();
        fd.append('action', action);
        Object.entries(params).forEach(([k,v]) => fd.append(k,v));
        const r = await fetch(API, {method:'POST', body:fd});
        return r.ok ? r.json() : null;
    } catch(e) { return null; }
}

function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function fmtTime(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    return isNaN(d) ? ts : d.toLocaleString(undefined, {month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
}

function levelPill(level) {
    const n = parseInt(level)||0;
    if (n >= 12) return `<span class="level-pill lv-crit">Critical ${n}</span>`;
    if (n >= 10) return `<span class="level-pill lv-high">High ${n}</span>`;
    if (n >= 7)  return `<span class="level-pill lv-med">Medium ${n}</span>`;
    return `<span class="level-pill lv-low">Low ${n}</span>`;
}

function toast(type, msg) {
    const id = 'toast-' + Date.now();
    const icons = {success:'check-circle',danger:'circle-xmark',info:'circle-info'};
    const cont = document.getElementById('toasts');
    cont.insertAdjacentHTML('beforeend', `
        <div id="${id}" class="sw-toast ${type}">
            <div class="toast-icon"><i class="fas fa-${icons[type]||'circle-info'}"></i></div>
            <span>${msg}</span>
            <button class="toast-close" onclick="document.getElementById('${id}').remove()">&times;</button>
        </div>`);
    setTimeout(() => document.getElementById(id)?.remove(), 5000);
}

// ── Init ──────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    refreshAll();
    refreshTimer = setInterval(refreshAll, 30000);
});
