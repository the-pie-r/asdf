#!/bin/bash
# SentinelWatch — Deploy & Fix Script
# Run: sudo bash deploy.sh
set -e
WEB=/var/www/html/wazuh-dashboard
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "========================================"
echo " SentinelWatch Deploy Script"
echo "========================================"

# 1. Copy all flat files to web root
echo "[1/6] Copying files to ${WEB}..."
mkdir -p "$WEB"
cp "$SCRIPT_DIR"/*.php "$WEB"/
cp "$SCRIPT_DIR"/*.js  "$WEB"/
cp "$SCRIPT_DIR"/*.sql "$WEB"/ 2>/dev/null || true

# 2. Permissions
echo "[2/6] Setting permissions..."
chown -R www-data:www-data "$WEB"
chmod -R 755 "$WEB"

# 3. Allow www-data to run iptables + cron script without password
echo "[3/6] Configuring sudoers..."
cat > /etc/sudoers.d/sentinelwatch << 'SUDOEOF'
www-data ALL=(ALL) NOPASSWD: /sbin/iptables, /usr/sbin/iptables, /usr/bin/iptables
www-data ALL=(ALL) NOPASSWD: /usr/bin/php /var/www/html/wazuh-dashboard/cron_alerts.php
SUDOEOF
chmod 440 /etc/sudoers.d/sentinelwatch

# 4. cron_alerts.php needs to read Wazuh alerts.json
echo "[4/6] Granting alerts.json read access..."
usermod -aG ossec www-data 2>/dev/null || true
chmod g+rx /var/ossec/logs/ 2>/dev/null || true
chmod g+rx /var/ossec/logs/alerts/ 2>/dev/null || true
chmod g+r  /var/ossec/logs/alerts/alerts.json 2>/dev/null || true

# 5. Set up cron
echo "[5/6] Setting up cron job..."
(crontab -l 2>/dev/null | grep -v cron_alerts; \
 echo "* * * * * /usr/bin/php ${WEB}/cron_alerts.php >> /var/log/sentinel-cron.log 2>&1") | crontab -

# 6. Restart Apache
echo "[6/6] Restarting Apache..."
systemctl restart apache2

echo ""
echo "========================================"
echo " DONE! Run a quick test:"
echo "  sudo php ${WEB}/cron_alerts.php"
echo "  sudo tail -20 /var/log/sentinel-cron.log"
echo "  curl -s http://localhost/wazuh-dashboard/api.php?action=stats"
echo "========================================"
