<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
if (!isLoggedIn()) { header('Location: login.php'); exit(); }
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SentinelWatch — Security Dashboard</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
:root{--bg:#060d1a;--sidebar:#0a1628;--card:#0f1e35;--card2:#0d1b30;--border:rgba(255,255,255,.07);--text:#e2e8f0;--muted:#64748b;--accent:#dc2626;--accent2:#2563eb;--success:#16a34a;--warn:#d97706;--glow:rgba(220,38,38,.25)}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;min-height:100vh;overflow-x:hidden}

/* ── NAVBAR ── */
.sw-navbar{position:fixed;top:0;left:0;right:0;height:58px;background:rgba(6,13,26,.95);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 20px;z-index:1000;gap:16px}
.sw-brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:inherit}
.sw-brand-icon{width:34px;height:34px;background:linear-gradient(135deg,var(--accent),#991b1b);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:.9rem;color:#fff;box-shadow:0 0 12px var(--glow)}
.sw-brand span{font-weight:800;font-size:1.1rem;letter-spacing:-.3px}
.sw-brand small{color:var(--muted);font-size:.7rem;font-weight:400;display:block;line-height:1}
.sw-nav-right{margin-left:auto;display:flex;align-items:center;gap:12px}
.live-badge{display:flex;align-items:center;gap:6px;background:rgba(22,163,74,.12);border:1px solid rgba(22,163,74,.25);color:#4ade80;border-radius:20px;padding:4px 10px;font-size:.75rem;font-weight:600}
.live-dot{width:7px;height:7px;background:#4ade80;border-radius:50%;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(74,222,128,.4)}50%{opacity:.7;box-shadow:0 0 0 4px rgba(74,222,128,0)}}
.nav-user{color:var(--muted);font-size:.82rem}
.btn-logout{background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.25);color:#f87171;border-radius:8px;padding:5px 12px;font-size:.8rem;cursor:pointer;transition:.2s;text-decoration:none}
.btn-logout:hover{background:rgba(220,38,38,.2);color:#fca5a5}
.last-update{color:var(--muted);font-size:.72rem}

/* ── SIDEBAR ── */
.sw-sidebar{position:fixed;top:58px;left:0;width:220px;height:calc(100vh - 58px);background:var(--sidebar);border-right:1px solid var(--border);overflow-y:auto;z-index:100;padding:16px 0}
.sw-sidebar::-webkit-scrollbar{width:4px}
.sw-sidebar::-webkit-scrollbar-track{background:transparent}
.sw-sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:2px}
.nav-section{color:var(--muted);font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;padding:14px 20px 6px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 20px;color:var(--muted);cursor:pointer;transition:.15s;font-size:.86rem;border-left:3px solid transparent;text-decoration:none}
.nav-item:hover{color:var(--text);background:rgba(255,255,255,.04)}
.nav-item.active{color:#fff;background:rgba(220,38,38,.1);border-left-color:var(--accent)}
.nav-item i{width:16px;text-align:center;font-size:.85rem}
.nav-badge{margin-left:auto;background:var(--accent);color:#fff;border-radius:10px;padding:2px 7px;font-size:.65rem;font-weight:700}

/* ── MAIN ── */
.sw-main{margin-left:220px;margin-top:58px;padding:28px;min-height:calc(100vh - 58px)}

/* ── PAGE HEADER ── */
.page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid var(--border)}
.page-title{font-size:1.3rem;font-weight:700}
.page-title small{display:block;color:var(--muted);font-size:.75rem;font-weight:400;margin-top:2px}

/* ── STAT CARDS ── */
.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:20px;position:relative;overflow:hidden;transition:.2s}
.stat-card::before{content:'';position:absolute;inset:0;border-radius:16px;opacity:0;transition:.3s}
.stat-card:hover::before{opacity:1}
.stat-card.red::before{background:linear-gradient(135deg,rgba(220,38,38,.08),transparent)}
.stat-card.amber::before{background:linear-gradient(135deg,rgba(217,119,6,.08),transparent)}
.stat-card.green::before{background:linear-gradient(135deg,rgba(22,163,74,.08),transparent)}
.stat-card.blue::before{background:linear-gradient(135deg,rgba(37,99,235,.08),transparent)}
.stat-icon{width:42px;height:42px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;margin-bottom:14px}
.stat-icon.red{background:rgba(220,38,38,.15);color:#f87171}
.stat-icon.amber{background:rgba(217,119,6,.15);color:#fbbf24}
.stat-icon.green{background:rgba(22,163,74,.15);color:#4ade80}
.stat-icon.blue{background:rgba(37,99,235,.15);color:#60a5fa}
.stat-value{font-size:2rem;font-weight:800;line-height:1;margin-bottom:4px;letter-spacing:-1px}
.stat-label{color:var(--muted);font-size:.78rem;font-weight:500}
.stat-sub{color:var(--muted);font-size:.72rem;margin-top:6px}
.stat-delta{font-size:.72rem;font-weight:600;margin-top:6px}
.delta-up{color:#f87171}
.delta-ok{color:#4ade80}
.stat-border-red{border-top:3px solid var(--accent)}
.stat-border-amber{border-top:3px solid var(--warn)}
.stat-border-green{border-top:3px solid var(--success)}
.stat-border-blue{border-top:3px solid var(--accent2)}

/* ── CARDS ── */
.sw-card{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;margin-bottom:20px}
.sw-card-header{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:var(--card2)}
.sw-card-title{font-weight:700;font-size:.9rem;display:flex;align-items:center;gap:8px}
.sw-card-body{padding:20px}
.sw-card-body.p0{padding:0}

/* ── TABLE ── */
.sw-table{width:100%;border-collapse:collapse;font-size:.83rem}
.sw-table th{padding:11px 14px;color:var(--muted);font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border);white-space:nowrap;background:var(--card2)}
.sw-table td{padding:11px 14px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
.sw-table tr:last-child td{border-bottom:none}
.sw-table tbody tr{transition:.15s;cursor:default}
.sw-table tbody tr:hover{background:rgba(255,255,255,.03)}
.ip-tag{font-family:monospace;background:rgba(37,99,235,.15);color:#93c5fd;padding:3px 8px;border-radius:6px;font-size:.8rem}
.level-pill{display:inline-flex;align-items:center;padding:3px 9px;border-radius:20px;font-size:.72rem;font-weight:700;white-space:nowrap}
.lv-crit{background:rgba(220,38,38,.2);color:#fca5a5;border:1px solid rgba(220,38,38,.3)}
.lv-high{background:rgba(234,88,12,.2);color:#fdba74;border:1px solid rgba(234,88,12,.3)}
.lv-med{background:rgba(217,119,6,.2);color:#fcd34d;border:1px solid rgba(217,119,6,.3)}
.lv-low{background:rgba(22,163,74,.2);color:#86efac;border:1px solid rgba(22,163,74,.3)}
.agent-tag{background:rgba(37,99,235,.1);color:#93c5fd;padding:3px 8px;border-radius:6px;font-size:.78rem}

/* ── BUTTONS ── */
.btn-sm-red{background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.3);color:#f87171;border-radius:7px;padding:4px 10px;font-size:.75rem;cursor:pointer;transition:.15s}
.btn-sm-red:hover{background:rgba(220,38,38,.3);color:#fff}
.btn-sm-green{background:rgba(22,163,74,.15);border:1px solid rgba(22,163,74,.3);color:#4ade80;border-radius:7px;padding:4px 10px;font-size:.75rem;cursor:pointer;transition:.15s}
.btn-sm-green:hover{background:rgba(22,163,74,.3)}
.btn-sm-slack{background:rgba(79,70,229,.15);border:1px solid rgba(79,70,229,.3);color:#a5b4fc;border-radius:7px;padding:4px 10px;font-size:.75rem;cursor:pointer;transition:.15s}
.btn-primary-sw{background:linear-gradient(135deg,var(--accent),#991b1b);border:none;color:#fff;border-radius:9px;padding:9px 18px;font-size:.85rem;font-weight:600;cursor:pointer;transition:.2s}
.btn-primary-sw:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(220,38,38,.35)}
.btn-outline-sw{background:transparent;border:1px solid var(--border);color:var(--text);border-radius:9px;padding:8px 16px;font-size:.83rem;cursor:pointer;transition:.15s}
.btn-outline-sw:hover{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.15)}

/* ── FORM CONTROLS ── */
.sw-input{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--text);border-radius:9px;padding:10px 14px;font-size:.85rem;width:100%;transition:.15s}
.sw-input:focus{outline:none;border-color:var(--accent);background:rgba(255,255,255,.07);box-shadow:0 0 0 3px rgba(220,38,38,.15)}
.sw-select{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--text);border-radius:9px;padding:8px 12px;font-size:.83rem;cursor:pointer}
.sw-select option{background:#0f1e35}
.sw-label{color:var(--muted);font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.5px;display:block;margin-bottom:6px}
.sw-form-group{margin-bottom:18px}
.sw-toggle{position:relative;width:44px;height:24px;display:inline-block}
.sw-toggle input{opacity:0;width:0;height:0}
.sw-toggle-slider{position:absolute;inset:0;background:#1e293b;border:1px solid rgba(255,255,255,.1);border-radius:24px;cursor:pointer;transition:.3s}
.sw-toggle-slider:before{content:'';position:absolute;width:18px;height:18px;left:2px;bottom:2px;background:#475569;border-radius:50%;transition:.3s}
.sw-toggle input:checked+.sw-toggle-slider{background:rgba(22,163,74,.3);border-color:rgba(22,163,74,.5)}
.sw-toggle input:checked+.sw-toggle-slider:before{transform:translateX(20px);background:#4ade80}

/* ── AGENT CARDS ── */
.agent-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:18px;transition:.2s}
.agent-card:hover{border-color:rgba(255,255,255,.15);transform:translateY(-2px)}
.agent-status{display:flex;align-items:center;gap:7px;font-size:.78rem;font-weight:600}
.dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.dot-active{background:#4ade80;box-shadow:0 0 8px rgba(74,222,128,.6)}
.dot-disco{background:#f87171}
.dot-pend{background:#fbbf24}
.dot-never{background:#475569}
.agent-name{font-weight:700;font-size:.95rem;margin:8px 0 4px}
.agent-meta{color:var(--muted);font-size:.78rem;line-height:1.7}

/* ── PROGRESS BARS ── */
.sw-bar-track{background:rgba(255,255,255,.06);border-radius:4px;height:6px;overflow:hidden}
.sw-bar-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,var(--accent),#ef4444);transition:width .6s ease}

/* ── SLACK LOG ── */
.slack-entry{padding:12px 16px;border-bottom:1px solid var(--border);font-size:.8rem}
.slack-entry:last-child{border-bottom:none}
.slack-entry.ok .slack-marker{color:#4ade80}
.slack-entry.fail .slack-marker{color:#f87171}

/* ── SECTIONS ── */
.sw-section{display:none}
.sw-section.active{display:block}

/* ── TOAST ── */
.sw-toasts{position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px}
.sw-toast{display:flex;align-items:center;gap:12px;padding:14px 18px;border-radius:12px;background:var(--card);border:1px solid var(--border);min-width:280px;box-shadow:0 8px 32px rgba(0,0,0,.4);animation:slideIn .3s ease;font-size:.85rem}
@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
.sw-toast.success{border-color:rgba(22,163,74,.4)}
.sw-toast.danger{border-color:rgba(220,38,38,.4)}
.sw-toast.info{border-color:rgba(37,99,235,.4)}
.toast-icon{width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0}
.sw-toast.success .toast-icon{background:rgba(22,163,74,.2);color:#4ade80}
.sw-toast.danger  .toast-icon{background:rgba(220,38,38,.2);color:#f87171}
.sw-toast.info    .toast-icon{background:rgba(37,99,235,.2);color:#60a5fa}
.toast-close{margin-left:auto;background:none;border:none;color:var(--muted);cursor:pointer;font-size:1rem;padding:0;line-height:1}

/* ── MISC ── */
.empty-state{text-align:center;padding:48px 20px;color:var(--muted)}
.empty-state i{font-size:2.5rem;margin-bottom:12px;display:block;opacity:.3}
.section-tabs{display:flex;gap:4px;background:rgba(255,255,255,.04);border-radius:10px;padding:4px}
.stab{padding:7px 16px;border-radius:7px;font-size:.82rem;cursor:pointer;color:var(--muted);transition:.15s;border:none;background:none}
.stab.active{background:rgba(220,38,38,.2);color:#f87171;font-weight:600}
.divider{border:none;border-top:1px solid var(--border);margin:20px 0}
.top-ip-bar{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.04)}
.top-ip-bar:last-child{border-bottom:none}
code.mini{font-family:monospace;background:rgba(37,99,235,.15);color:#93c5fd;padding:2px 7px;border-radius:5px;font-size:.8rem}
</style>
</head>
<body>

<!-- ── NAVBAR ─────────────────────────────────── -->
<nav class="sw-navbar">
    <a class="sw-brand" href="#">
        <div class="sw-brand-icon"><i class="fas fa-shield-halved"></i></div>
        <div><span>SentinelWatch</span><small>Brute Force Detection Platform</small></div>
    </a>
    <div class="sw-nav-right">
        <div class="live-badge"><span class="live-dot"></span>LIVE</div>
        <span class="last-update" id="last-update">updating...</span>
        <span class="nav-user"><i class="fas fa-user-shield me-1"></i><?= htmlspecialchars($_SESSION['username']) ?></span>
        <a href="logout.php" class="btn-logout"><i class="fas fa-arrow-right-from-bracket me-1"></i>Logout</a>
    </div>
</nav>

<!-- ── SIDEBAR ────────────────────────────────── -->
<nav class="sw-sidebar">
    <div class="nav-section">Detection</div>
    <a class="nav-item active" onclick="showSection('overview')" href="#">
        <i class="fas fa-gauge-high"></i>Overview
    </a>
    <a class="nav-item" onclick="showSection('alerts')" href="#">
        <i class="fas fa-triangle-exclamation"></i>Alerts
        <span class="nav-badge" id="nav-alert-count">0</span>
    </a>
    <a class="nav-item" onclick="showSection('blocked')" href="#">
        <i class="fas fa-ban"></i>Blocked IPs
        <span class="nav-badge" id="nav-blocked-count">0</span>
    </a>

    <div class="nav-section">Infrastructure</div>
    <a class="nav-item" onclick="showSection('agents')" href="#">
        <i class="fas fa-server"></i>Agents
    </a>

    <div class="nav-section">Notifications</div>
    <a class="nav-item" onclick="showSection('slack')" href="#">
        <i class="fab fa-slack"></i>Slack Config
    </a>

    <div class="nav-section">System</div>
    <a class="nav-item" onclick="showSection('settings')" href="#">
        <i class="fas fa-gear"></i>Settings
    </a>
    <a class="nav-item" onclick="runCron()" href="#">
        <i class="fas fa-rotate"></i>Force Sync
    </a>
</nav>

<!-- ── MAIN ───────────────────────────────────── -->
<main class="sw-main">

<!-- ═══ OVERVIEW ═══════════════════════════════ -->
<div id="section-overview" class="sw-section active">
    <div class="page-header">
        <div class="page-title">Security Overview <small>Real-time brute force detection dashboard</small></div>
        <div style="display:flex;gap:8px;align-items:center">
            <select class="sw-select" id="overview-timeframe" onchange="refreshAll()">
                <option value="1">Last 1 Hour</option>
                <option value="24" selected>Last 24 Hours</option>
                <option value="168">Last 7 Days</option>
            </select>
            <button class="btn-outline-sw" onclick="refreshAll()"><i class="fas fa-rotate me-1"></i>Refresh</button>
        </div>
    </div>

    <!-- Stat Cards -->
    <div class="stat-grid">
        <div class="stat-card red stat-border-red">
            <div class="stat-icon red"><i class="fas fa-fire"></i></div>
            <div class="stat-value" id="s-total">—</div>
            <div class="stat-label">Brute Force Alerts</div>
            <div class="stat-sub" id="s-total-sub">Last 24 hours</div>
        </div>
        <div class="stat-card amber stat-border-amber">
            <div class="stat-icon amber"><i class="fas fa-globe"></i></div>
            <div class="stat-value" id="s-ips">—</div>
            <div class="stat-label">Unique Attacker IPs</div>
            <div class="stat-sub">Active threats detected</div>
        </div>
        <div class="stat-card green stat-border-green">
            <div class="stat-icon green"><i class="fas fa-server"></i></div>
            <div class="stat-value" id="s-agents">—</div>
            <div class="stat-label">Agents Online</div>
            <div class="stat-sub" id="s-agents-sub">Monitored endpoints</div>
        </div>
        <div class="stat-card blue stat-border-blue">
            <div class="stat-icon blue"><i class="fas fa-ban"></i></div>
            <div class="stat-value" id="s-blocked">—</div>
            <div class="stat-label">Blocked IPs</div>
            <div class="stat-sub">Active iptables rules</div>
        </div>
    </div>

    <!-- Charts Row -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;margin-bottom:20px">
        <div class="sw-card">
            <div class="sw-card-header">
                <div class="sw-card-title"><i class="fas fa-chart-area" style="color:#2563eb"></i>Attack Timeline (24h)</div>
            </div>
            <div class="sw-card-body"><canvas id="timelineChart" height="90"></canvas></div>
        </div>
        <div class="sw-card">
            <div class="sw-card-header">
                <div class="sw-card-title"><i class="fas fa-chart-donut" style="color:#d97706"></i>Attack Types</div>
            </div>
            <div class="sw-card-body"><canvas id="typeChart" height="160"></canvas></div>
        </div>
    </div>

    <!-- Bottom Row: Recent Alerts + Top IPs -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px">
        <div class="sw-card">
            <div class="sw-card-header">
                <div class="sw-card-title"><i class="fas fa-list" style="color:#dc2626"></i>Recent Alerts</div>
                <span style="background:rgba(220,38,38,.15);color:#f87171;border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700" id="recent-count">0</span>
            </div>
            <div class="sw-card-body p0">
                <div style="overflow-x:auto;max-height:380px;overflow-y:auto">
                    <table class="sw-table">
                        <thead><tr><th>Time</th><th>IP</th><th>Agent</th><th>Level</th><th>Description</th><th></th></tr></thead>
                        <tbody id="recent-tbody"><tr><td colspan="6"><div class="empty-state"><i class="fas fa-spinner fa-spin"></i>Loading...</div></td></tr></tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="sw-card">
            <div class="sw-card-header">
                <div class="sw-card-title"><i class="fas fa-ranking-star" style="color:#f59e0b"></i>Top Attacker IPs</div>
            </div>
            <div class="sw-card-body">
                <div id="top-ips-list"><div class="empty-state" style="padding:20px"><i class="fas fa-spinner fa-spin" style="font-size:1.2rem"></i></div></div>
            </div>
        </div>
    </div>
</div>

<!-- ═══ ALERTS ══════════════════════════════════ -->
<div id="section-alerts" class="sw-section">
    <div class="page-header">
        <div class="page-title">Brute Force Alerts <small>All detected attack events</small></div>
        <div style="display:flex;gap:8px">
            <select class="sw-select" id="alert-hours">
                <option value="1">Last 1h</option>
                <option value="24" selected>Last 24h</option>
                <option value="168">Last 7d</option>
            </select>
            <button class="btn-outline-sw" onclick="loadAlerts()"><i class="fas fa-rotate me-1"></i>Refresh</button>
        </div>
    </div>
    <div class="sw-card">
        <div class="sw-card-body p0">
            <div style="overflow-x:auto">
                <table class="sw-table">
                    <thead><tr><th>Timestamp</th><th>Source IP</th><th>Agent</th><th>Rule</th><th>Level</th><th>Type</th><th>Description</th><th>Actions</th></tr></thead>
                    <tbody id="all-alerts-tbody"><tr><td colspan="8"><div class="empty-state"><i class="fas fa-spinner fa-spin"></i>Loading...</div></td></tr></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ═══ BLOCKED IPs ══════════════════════════════ -->
<div id="section-blocked" class="sw-section">
    <div class="page-header">
        <div class="page-title">Blocked IPs <small>Active iptables DROP rules</small></div>
        <button class="btn-outline-sw" onclick="loadBlocked()"><i class="fas fa-rotate me-1"></i>Refresh</button>
    </div>
    <div class="sw-card">
        <div class="sw-card-body p0">
            <table class="sw-table">
                <thead><tr><th>IP Address</th><th>Blocked At</th><th>Reason</th><th>Agent</th><th>Action</th></tr></thead>
                <tbody id="blocked-tbody"><tr><td colspan="5"><div class="empty-state"><i class="fas fa-spinner fa-spin"></i>Loading...</div></td></tr></tbody>
            </table>
        </div>
    </div>
</div>

<!-- ═══ AGENTS ═══════════════════════════════════ -->
<div id="section-agents" class="sw-section">
    <div class="page-header">
        <div class="page-title">Wazuh Agents <small>Connected endpoint monitors</small></div>
        <button class="btn-outline-sw" onclick="loadAgents()"><i class="fas fa-rotate me-1"></i>Refresh</button>
    </div>
    <div class="row g-3" id="agents-grid" style="--bs-gutter-x:16px"></div>
</div>

<!-- ═══ SLACK ════════════════════════════════════ -->
<div id="section-slack" class="sw-section">
    <div class="page-header">
        <div class="page-title">Slack Notifications <small>Configure alert delivery</small></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div class="sw-card">
            <div class="sw-card-header"><div class="sw-card-title"><i class="fab fa-slack" style="color:#4a154b"></i>Webhook Settings</div></div>
            <div class="sw-card-body">
                <div class="sw-form-group">
                    <label class="sw-label">Webhook URL</label>
                    <input type="url" id="slack-webhook" class="sw-input" placeholder="https://hooks.slack.com/services/...">
                </div>
                <div class="sw-form-group">
                    <label class="sw-label">Channel</label>
                    <input type="text" id="slack-channel" class="sw-input" placeholder="#security-alerts">
                </div>
                <div class="sw-form-group">
                    <label class="sw-label">Minimum Alert Level</label>
                    <select id="slack-level" class="sw-select" style="width:100%">
                        <option value="5">Level 5+ (Low)</option>
                        <option value="7">Level 7+ (Medium)</option>
                        <option value="10" selected>Level 10+ (High)</option>
                        <option value="12">Level 12+ (Critical)</option>
                    </select>
                </div>
                <div style="display:flex;gap:10px;margin-top:20px">
                    <button class="btn-primary-sw" onclick="saveSlack()"><i class="fas fa-save me-1"></i>Save</button>
                    <button class="btn-outline-sw" onclick="testSlack()"><i class="fas fa-paper-plane me-1"></i>Test Message</button>
                </div>
            </div>
        </div>
        <div class="sw-card">
            <div class="sw-card-header"><div class="sw-card-title"><i class="fas fa-bell" style="color:#f59e0b"></i>Notification Log</div></div>
            <div id="slack-log-body" style="max-height:400px;overflow-y:auto">
                <div class="empty-state"><i class="fas fa-bell-slash"></i>No notifications yet</div>
            </div>
        </div>
    </div>
</div>

<!-- ═══ SETTINGS ═════════════════════════════════ -->
<div id="section-settings" class="sw-section">
    <div class="page-header">
        <div class="page-title">Settings <small>Wazuh API &amp; auto-block configuration</small></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div class="sw-card">
            <div class="sw-card-header"><div class="sw-card-title"><i class="fas fa-plug" style="color:#60a5fa"></i>Wazuh API</div></div>
            <div class="sw-card-body">
                <div class="sw-form-group"><label class="sw-label">Manager IP</label><input id="wazuh-ip" class="sw-input" placeholder="127.0.0.1"></div>
                <div class="sw-form-group"><label class="sw-label">API Port</label><input id="wazuh-port" class="sw-input" value="55000"></div>
                <div class="sw-form-group"><label class="sw-label">API Username</label><input id="wazuh-user" class="sw-input" value="wazuh"></div>
                <div class="sw-form-group"><label class="sw-label">API Password</label><input type="password" id="wazuh-pass" class="sw-input" placeholder="••••••••"></div>
                <div style="display:flex;gap:10px">
                    <button class="btn-primary-sw" onclick="saveWazuh()"><i class="fas fa-save me-1"></i>Save</button>
                    <button class="btn-outline-sw" onclick="testWazuh()"><i class="fas fa-plug me-1"></i>Test Connection</button>
                </div>
            </div>
        </div>
        <div class="sw-card">
            <div class="sw-card-header"><div class="sw-card-title"><i class="fas fa-shield-virus" style="color:#f87171"></i>Auto-Block Rules</div></div>
            <div class="sw-card-body">
                <div class="sw-form-group">
                    <label class="sw-label">Block Threshold (failed attempts)</label>
                    <input id="block-threshold" class="sw-input" type="number" value="5">
                    <div style="color:var(--muted);font-size:.75rem;margin-top:5px">Block IP after N attempts within 10 minutes</div>
                </div>
                <div class="sw-form-group">
                    <label class="sw-label">Block Duration (minutes)</label>
                    <input id="block-duration" class="sw-input" type="number" value="60">
                </div>
                <div class="sw-form-group" style="display:flex;align-items:center;gap:12px">
                    <label class="sw-toggle"><input type="checkbox" id="auto-block" checked><span class="sw-toggle-slider"></span></label>
                    <span style="font-size:.85rem">Enable Auto-Block</span>
                </div>
                <button class="btn-primary-sw" onclick="saveBlock()"><i class="fas fa-save me-1"></i>Save Settings</button>
            </div>
        </div>
    </div>
</div>

</main>

<!-- Toasts -->
<div class="sw-toasts" id="toasts"></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.3.0/chart.umd.min.js"></script>
<script src="dashboard.js"></script>
</body>
</html>
