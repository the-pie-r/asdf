<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
if (isLoggedIn()) { header('Location: index.php'); exit(); }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (login(trim($_POST['username']??''), $_POST['password']??'')) {
        header('Location: index.php'); exit();
    }
    $error='Invalid credentials. Please try again.';
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SentinelWatch — Login</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;background:#060d1a;display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',system-ui,sans-serif;overflow:hidden}
.bg-grid{position:fixed;inset:0;background-image:linear-gradient(rgba(0,180,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,180,255,.03) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}
.glow-orb{position:fixed;border-radius:50%;filter:blur(80px);pointer-events:none}
.orb1{width:400px;height:400px;background:rgba(220,38,38,.15);top:-100px;left:-100px}
.orb2{width:300px;height:300px;background:rgba(37,99,235,.12);bottom:-80px;right:-80px}
.login-wrap{position:relative;z-index:10;width:100%;max-width:420px;padding:20px}
.brand{text-align:center;margin-bottom:32px}
.brand-icon{width:72px;height:72px;background:linear-gradient(135deg,#dc2626,#991b1b);border-radius:20px;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;box-shadow:0 0 30px rgba(220,38,38,.4)}
.brand h1{font-size:1.8rem;font-weight:800;color:#fff;letter-spacing:-.5px;margin:0}
.brand p{color:#64748b;font-size:.85rem;margin:4px 0 0}
.card-login{background:rgba(15,23,42,.8);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.07);border-radius:20px;padding:36px}
.form-control{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#e2e8f0;border-radius:10px;padding:12px 16px}
.form-control:focus{background:rgba(255,255,255,.08);border-color:#dc2626;color:#e2e8f0;box-shadow:0 0 0 3px rgba(220,38,38,.2)}
.form-control::placeholder{color:#475569}
.input-group-text{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#64748b;border-radius:10px 0 0 10px}
.btn-login{background:linear-gradient(135deg,#dc2626,#b91c1c);border:none;border-radius:10px;padding:13px;font-weight:700;font-size:1rem;color:#fff;width:100%;transition:.2s;letter-spacing:.3px}
.btn-login:hover{background:linear-gradient(135deg,#ef4444,#dc2626);transform:translateY(-1px);box-shadow:0 8px 20px rgba(220,38,38,.4)}
.form-label{color:#94a3b8;font-size:.85rem;font-weight:600;text-transform:uppercase;letter-spacing:.5px}
.alert-danger{background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.3);color:#fca5a5;border-radius:10px}
.version{text-align:center;color:#1e3a5f;font-size:.75rem;margin-top:20px}
</style>
</head>
<body>
<div class="bg-grid"></div>
<div class="glow-orb orb1"></div>
<div class="glow-orb orb2"></div>
<div class="login-wrap">
    <div class="brand">
        <div class="brand-icon"><i class="fas fa-shield-halved fa-2x text-white"></i></div>
        <h1>SentinelWatch</h1>
        <p>Brute Force Detection &amp; Response Platform</p>
    </div>
    <div class="card-login">
        <?php if($error): ?>
        <div class="alert alert-danger mb-4 py-2 small"><i class="fas fa-circle-xmark me-2"></i><?=htmlspecialchars($error)?></div>
        <?php endif; ?>
        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label class="form-label mb-2">Username</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Enter username" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label mb-2">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Enter password" required>
                </div>
            </div>
            <button type="submit" class="btn-login">
                <i class="fas fa-arrow-right-to-bracket me-2"></i>Sign In
            </button>
        </form>
    </div>
    <p class="version">SentinelWatch v2.0 • Powered by Wazuh</p>
</div>
</body>
</html>
