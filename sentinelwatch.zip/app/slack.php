<?php
class SlackNotifier {
    private string $webhook;
    private string $channel;

    public function __construct(?array $s = null) {
        $this->webhook = $s['slack_webhook'] ?? SLACK_WEBHOOK_URL;
        $this->channel = $s['slack_channel'] ?? SLACK_CHANNEL;
    }

    public function sendAlert(array $a): bool {
        $ip    = $a['src_ip']      ?? $a['srcip']      ?? 'Unknown';
        $agent = $a['agent_name']  ?? 'Unknown';
        $rule  = $a['rule_id']     ?? 'Unknown';
        $desc  = $a['description'] ?? 'Brute force detected';
        $level = (int)($a['rule_level'] ?? $a['level'] ?? 0);
        $time  = $a['timestamp']   ?? $a['created_at'] ?? date('Y-m-d H:i:s');
        $type  = $a['attack_type'] ?? 'Brute Force';

        $color = $level >= 12 ? '#cc0000' : ($level >= 10 ? '#ff6600' : '#ffaa00');
        $emoji = $level >= 12 ? ':rotating_light:' : ':warning:';

        return $this->post([
            'channel'     => $this->channel,
            'username'    => 'SentinelWatch',
            'icon_emoji'  => ':shield:',
            'attachments' => [[
                'color'    => $color,
                'pretext'  => "{$emoji} *BRUTE FORCE DETECTED — Level {$level}*",
                'fields'   => [
                    ['title'=>'Source IP',   'value'=>"`{$ip}`",       'short'=>true],
                    ['title'=>'Agent',       'value'=>$agent,          'short'=>true],
                    ['title'=>'Attack Type', 'value'=>$type,           'short'=>true],
                    ['title'=>'Rule',        'value'=>"ID: {$rule}",   'short'=>true],
                    ['title'=>'Description', 'value'=>$desc,           'short'=>false],
                    ['title'=>'Time',        'value'=>$time,           'short'=>false],
                ],
                'footer' => 'SentinelWatch | ' . gethostname(),
                'ts'     => time(),
            ]]
        ]);
    }

    public function sendTest(): bool {
        return $this->post(['channel'=>$this->channel,'username'=>'SentinelWatch','icon_emoji'=>':shield:',
            'text'=>':white_check_mark: *SentinelWatch* — Slack connection is working!']);
    }

    public function sendBlockNotice(string $ip, int $attempts, string $agent): bool {
        return $this->post(['channel'=>$this->channel,'username'=>'SentinelWatch','icon_emoji'=>':shield:',
            'attachments'=>[[
                'color'=>'#cc0000',
                'pretext'=>':no_entry: *IP AUTO-BLOCKED*',
                'fields'=>[
                    ['title'=>'Blocked IP',       'value'=>"`{$ip}`",          'short'=>true],
                    ['title'=>'Triggered by Agent','value'=>$agent,             'short'=>true],
                    ['title'=>'Reason',            'value'=>"{$attempts} brute-force attempts in 10 minutes",'short'=>false],
                    ['title'=>'Action',            'value'=>'iptables DROP rule applied via Wazuh Active Response','short'=>false],
                ],
                'footer'=>'SentinelWatch Auto-Block','ts'=>time()
            ]]
        ]);
    }

    private function post(array $payload): bool {
        if (empty($this->webhook)) return false;
        $ch = curl_init($this->webhook);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode($payload),
            CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
            CURLOPT_TIMEOUT=>10,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $ok = ($code===200 && $resp==='ok');
        try {
            getDB()->prepare("INSERT INTO slack_log(payload,response,success,created_at) VALUES(?,?,?,NOW())")
                   ->execute([json_encode($payload), $resp, (int)$ok]);
        } catch(Exception $e){}
        return $ok;
    }
}
