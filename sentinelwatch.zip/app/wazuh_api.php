<?php
class WazuhAPI {
    private string $host;
    private int    $port;
    private string $user;
    private string $pass;
    private string $token = '';

    public function __construct(?array $s = null) {
        $this->host = $s['wazuh_ip']   ?? WAZUH_API_HOST;
        $this->port = (int)($s['wazuh_port'] ?? WAZUH_API_PORT);
        $this->user = $s['wazuh_user'] ?? WAZUH_API_USER;
        $this->pass = $s['wazuh_pass'] ?? WAZUH_API_PASS;
    }

    public function authenticate(): bool {
        $url = "https://{$this->host}:{$this->port}/security/user/authenticate";
        $ch  = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => '',
            CURLOPT_USERPWD        => "{$this->user}:{$this->pass}",
            CURLOPT_HTTPAUTH       => CURLAUTH_BASIC,
            CURLOPT_TIMEOUT        => 10,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code === 200) {
            $data = json_decode($resp, true);
            $this->token = $data['data']['token'] ?? '';
            return !empty($this->token);
        }
        return false;
    }

    private function req(string $ep, string $method = 'GET', array $p = []): ?array {
        if (empty($this->token) && !$this->authenticate()) return null;
        $url = "https://{$this->host}:{$this->port}{$ep}";
        if ($method === 'GET' && $p) $url .= '?' . http_build_query($p);
        $ch = curl_init($url);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER     => ["Authorization: Bearer {$this->token}","Content-Type: application/json"],
            CURLOPT_TIMEOUT        => 15,
        ];
        if ($method === 'PUT') {
            $opts[CURLOPT_CUSTOMREQUEST] = 'PUT';
            $opts[CURLOPT_POSTFIELDS]    = json_encode($p);
        }
        curl_setopt_array($ch, $opts);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code === 401) { $this->token = ''; if ($this->authenticate()) return $this->req($ep,$method,$p); return null; }
        return json_decode($resp, true);
    }

    public function getAgents(): ?array {
        $r = $this->req('/agents','GET',['limit'=>500,'status'=>'active,disconnected,pending,never_connected']);
        return $r['data']['affected_items'] ?? null;
    }

    public function getManagerInfo(): ?array { return $this->req('/manager/info'); }

    public function blockIP(string $ip, string $agentId = '000'): bool {
        // Send active response to all agents
        $body = [
            "command"   => "firewall-drop",
            "arguments" => ["-", "null", "1.1", $ip],
            "alert"     => ["data" => ["srcip" => $ip]]
        ];
        $r = $this->req('/active-response','PUT', $body);
        return ($r['error'] ?? 1) === 0;
    }

    public function testConnection(): bool { return $this->authenticate(); }
    public function getToken(): string { return $this->token; }
}
