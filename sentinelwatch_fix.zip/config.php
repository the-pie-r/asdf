<?php
// config.php — SentinelWatch
define('DB_HOST', 'localhost');
define('DB_NAME', 'wazuh_dashboard');
define('DB_USER', 'wazuh_user');
define('DB_PASS', 'WazuhDB@2024!');   // ← your actual DB password
define('WAZUH_API_HOST', '127.0.0.1');
define('WAZUH_API_PORT', '55000');
define('WAZUH_API_USER', 'wazuh');
define('WAZUH_API_PASS', 'Wazuh@2024!');  // ← from your settings table
define('SLACK_WEBHOOK_URL', '');
define('SLACK_CHANNEL', '#security-alerts');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
             PDO::ATTR_EMULATE_PREPARES=>false]
        );
    }
    return $pdo;
}

function loadSettings(): array {
    try {
        $rows = getDB()->query("SELECT setting_key,setting_value FROM dashboard_settings")->fetchAll();
        $s = [];
        foreach ($rows as $r) $s[$r['setting_key']] = $r['setting_value'];
        return $s;
    } catch (Exception $e) {
        return [];
    }
}
