#!/usr/bin/env php
<?php
/**
 * SentinelWatch — cron_alerts.php
 * Location: /var/www/html/wazuh-dashboard/cron_alerts.php  (FLAT, no subfolders)
 * Cron: * * * * * /usr/bin/php /var/www/html/wazuh-dashboard/cron_alerts.php >> /var/log/sentinel-cron.log 2>&1
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/slack.php';

$startTime = microtime(true);
echo "[" . date('Y-m-d H:i:s') . "] SentinelWatch cron starting...\n";

$settings        = loadSettings();
$slack           = new SlackNotifier($settings);
$db              = getDB();
$SLACK_LEVEL     = (int)($settings['slack_level']     ?? 5);
$BLOCK_THRESHOLD = (int)($settings['block_threshold'] ?? 5);
$AUTO_BLOCK      = ($settings['auto_block'] ?? '1') === '1';

// ── Brute-force rule IDs ───────────────────────────────────────
$BF_RULES    = ['5503','5710','5711','5712','5716','5720','5758','5760','5763','5764','100002'];
$BF_KEYWORDS = ['brute','authentication fail','multiple auth','failed password','invalid user','sshd'];

$newAlerts = 0; $slackSent = 0; $autoBlocked = [];

// ── READ alerts.json directly — most reliable method ───────────
$alertsFile = '/var/ossec/logs/alerts/alerts.json';
if (!file_exists($alertsFile) || !is_readable($alertsFile)) {
    echo "[WARN] Cannot read {$alertsFile} — check permissions\n";
    echo "[TIP]  Run: sudo chmod g+r /var/ossec/logs/alerts/alerts.json\n";
    echo "[TIP]  Run: sudo usermod -aG ossec www-data\n";
    goto sync_iptables;
}

$fh = fopen($alertsFile, 'r');
if (!$fh) { echo "[ERROR] fopen failed\n"; goto sync_iptables; }

// Read last ~2MB (plenty for recent events)
$size = filesize($alertsFile);
fseek($fh, -min($size, 2 * 1024 * 1024), SEEK_END);
fgets($fh); // discard partial line

$processed = 0;
while (!feof($fh)) {
    $line = fgets($fh);
    if (!$line || !trim($line)) continue;
    $a = json_decode($line, true);
    if (!$a || !isset($a['rule'])) continue;
    $processed++;

    $ruleId    = (string)($a['rule']['id']          ?? '');
    $ruleLevel = (int)   ($a['rule']['level']        ?? 0);
    $groups    = implode(',', (array)($a['rule']['groups'] ?? []));
    $desc      = $a['rule']['description']           ?? '';
    $srcIp     = $a['data']['srcip']                 ?? $a['data']['src_ip'] ?? '';
    $agentId   = $a['agent']['id']                   ?? '000';
    $agentName = $a['agent']['name']                 ?? 'manager';
    $ts        = $a['timestamp']                     ?? date('Y-m-d\TH:i:s\Z');

    // Only process recent (last 5 minutes)
    $tsUnix = strtotime($ts);
    if ($tsUnix < time() - 300) continue;

    // Filter: brute-force events only
    $isBF = in_array($ruleId, $BF_RULES);
    if (!$isBF) {
        $haystack = strtolower($desc . ' ' . $groups);
        foreach ($BF_KEYWORDS as $kw) {
            if (strpos($haystack, $kw) !== false && $ruleLevel >= 5) { $isBF = true; break; }
        }
    }
    if (!$isBF || empty($srcIp)) continue;

    $tsMySQL    = date('Y-m-d H:i:s', $tsUnix);
    $minBucket  = date('Y-m-d H:i', $tsUnix);

    // Attack type
    $type = 'SSH Brute Force';
    if (stripos($desc,'ftp')  !==false) $type = 'FTP Brute Force';
    if (stripos($desc,'rdp')  !==false) $type = 'RDP Brute Force';
    if (stripos($desc,'web')  !==false) $type = 'Web Brute Force';
    if (stripos($desc,'smtp') !==false) $type = 'SMTP Brute Force';

    // Dedup: skip if already stored in this minute from same IP+rule
    try {
        $chk = $db->prepare("SELECT id FROM brute_force_alerts WHERE src_ip=? AND rule_id=? AND DATE_FORMAT(timestamp,'%Y-%m-%d %H:%i')=? LIMIT 1");
        $chk->execute([$srcIp, $ruleId, $minBucket]);
        if ($chk->fetch()) continue;

        $db->prepare("INSERT INTO brute_force_alerts (agent_id,agent_name,src_ip,rule_id,rule_level,description,attack_type,raw_log,timestamp,created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())")
           ->execute([$agentId,$agentName,$srcIp,$ruleId,$ruleLevel,$desc,$type,substr(json_encode($a),0,4000),$tsMySQL]);
        $newAlerts++;
    } catch (Exception $e) {
        echo "[WARN] Insert: " . $e->getMessage() . "\n";
        continue;
    }

    // Slack notification
    if ($ruleLevel >= $SLACK_LEVEL) {
        if ($slack->sendAlert(['src_ip'=>$srcIp,'agent_name'=>$agentName,'rule_id'=>$ruleId,
            'rule_level'=>$ruleLevel,'description'=>$desc,'attack_type'=>$type,'timestamp'=>$ts])) {
            $slackSent++;
        }
    }

    // Auto-block
    if ($AUTO_BLOCK && !isset($autoBlocked[$srcIp])) {
        $cnt = $db->prepare("SELECT COUNT(*) FROM brute_force_alerts WHERE src_ip=? AND created_at>=NOW()-INTERVAL 10 MINUTE");
        $cnt->execute([$srcIp]);
        $attempts = (int)$cnt->fetchColumn();
        if ($attempts >= $BLOCK_THRESHOLD) {
            $already = $db->prepare("SELECT id FROM blocked_ips WHERE ip_address=? AND is_active=1");
            $already->execute([$srcIp]);
            if (!$already->fetch()) {
                $esc = escapeshellarg($srcIp);
                exec("sudo iptables -I INPUT -s {$esc} -j DROP 2>&1", $o, $rc);
                if ($rc === 0) {
                    $db->prepare("INSERT INTO blocked_ips(ip_address,reason,agent_name,blocked_at,is_active) VALUES(?,?,?,NOW(),1) ON DUPLICATE KEY UPDATE is_active=1,blocked_at=NOW()")
                       ->execute([$srcIp,"Auto-blocked: {$attempts} attempts in 10min",$agentName]);
                    $autoBlocked[$srcIp] = true;
                    echo "[BLOCK] {$srcIp} ({$attempts} attempts)\n";
                    $slack->sendBlockNotice($srcIp, $attempts, $agentName);
                } else {
                    echo "[WARN] iptables failed for {$srcIp}: " . implode(' ',$o) . "\n";
                }
            }
        }
    }
}
fclose($fh);
echo "[INFO] Processed {$processed} log lines, {$newAlerts} new brute-force alerts\n";

// ── Sync iptables → DB (so dashboard always matches reality) ───
sync_iptables:
exec("sudo iptables -L INPUT -n 2>/dev/null | grep -oP '(?<=s )[\d.]+(?=/)' | sort -u", $iips, $rc);
if ($rc === 0 && !empty($iips)) {
    foreach ($iips as $ip) {
        $ip = trim($ip);
        if (empty($ip) || $ip === '0.0.0.0') continue;
        try {
            $db->prepare("INSERT INTO blocked_ips(ip_address,reason,agent_name,blocked_at,is_active) VALUES(?,?,?,NOW(),1) ON DUPLICATE KEY UPDATE is_active=1")
               ->execute([$ip,'Synced from iptables','system']);
        } catch(Exception $e){}
    }
    echo "[SYNC] " . count($iips) . " iptables blocks synced to DB\n";
}

// Mark unblocked
if (!empty($iips)) {
    $ph = implode(',', array_fill(0, count($iips), '?'));
    try {
        $db->prepare("UPDATE blocked_ips SET is_active=0 WHERE ip_address NOT IN ({$ph}) AND is_active=1")->execute($iips);
    } catch(Exception $e){}
} else {
    // No iptables blocks = unblock all in DB
    try { $db->query("UPDATE blocked_ips SET is_active=0 WHERE is_active=1"); } catch(Exception $e){}
}

$elapsed = round(microtime(true) - $startTime, 2);
echo "[DONE] alerts:{$newAlerts} slack:{$slackSent} blocked:" . count($autoBlocked) . " time:{$elapsed}s\n";
