#!/bin/bash
# SentinelWatch — fix_and_deploy.sh
# Run as: sudo bash fix_and_deploy.sh
set -e
WEB=/var/www/html/wazuh-dashboard
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "============================================"
echo " SentinelWatch — Full Fix & Deploy"
echo "============================================"

# ── Step 1: Wipe old broken structure ─────────────────────────
echo ""
echo "[1/9] Cleaning old files..."
rm -rf "$WEB"
mkdir -p "$WEB"

# ── Step 2: Copy all flat files ────────────────────────────────
echo "[2/9] Deploying flat file structure..."
for f in config.php auth.php wazuh_api.php slack.php api.php index.php login.php logout.php dashboard.js cron_alerts.php; do
    if [ -f "$SCRIPT_DIR/$f" ]; then
        cp "$SCRIPT_DIR/$f" "$WEB/$f"
        echo "  ✓ $f"
    else
        echo "  ✗ MISSING: $f"
    fi
done

# ── Step 3: Permissions ────────────────────────────────────────
echo "[3/9] Setting ownership..."
chown -R www-data:www-data "$WEB"
chmod -R 755 "$WEB"

# ── Step 4: Add www-data to ossec group (read alerts.json) ─────
echo "[4/9] Adding www-data to ossec group..."
usermod -aG ossec www-data
chmod g+rx /var/ossec/logs/ 2>/dev/null || true
chmod g+rx /var/ossec/logs/alerts/ 2>/dev/null || true
chmod g+r  /var/ossec/logs/alerts/alerts.json 2>/dev/null || true
echo "  ✓ Done (Apache restart will activate group)"

# ── Step 5: sudoers for iptables ───────────────────────────────
echo "[5/9] Configuring sudoers (iptables + cron)..."
cat > /etc/sudoers.d/sentinelwatch << 'SUDOEOF'
www-data ALL=(ALL) NOPASSWD: /sbin/iptables
www-data ALL=(ALL) NOPASSWD: /usr/sbin/iptables
www-data ALL=(ALL) NOPASSWD: /usr/bin/iptables
www-data ALL=(ALL) NOPASSWD: /usr/bin/php /var/www/html/wazuh-dashboard/cron_alerts.php
SUDOEOF
chmod 440 /etc/sudoers.d/sentinelwatch
echo "  ✓ /etc/sudoers.d/sentinelwatch written"

# ── Step 6: Fix auto_block setting in DB ──────────────────────
echo "[6/9] Enabling auto_block in DB..."
mysql -u wazuh_user -pWazuhDB@2024! wazuh_dashboard \
  -e "UPDATE dashboard_settings SET setting_value='1' WHERE setting_key='auto_block';" 2>/dev/null || \
mysql -u wazuh_user -p'Wazuh@2024!' wazuh_dashboard \
  -e "UPDATE dashboard_settings SET setting_value='1' WHERE setting_key='auto_block';" 2>/dev/null || \
echo "  ⚠ Could not update auto_block — do it manually in dashboard Settings"

# ── Step 7: Fix cron to point to flat file ─────────────────────
echo "[7/9] Fixing cron job..."
# Remove old broken cron entries
crontab -l 2>/dev/null | grep -v "cron_alerts" | crontab - 2>/dev/null || true
# Add correct flat-path entry
(crontab -l 2>/dev/null; echo "* * * * * /usr/bin/php ${WEB}/cron_alerts.php >> /var/log/sentinel-cron.log 2>&1") | crontab -
echo "  ✓ Cron updated: * * * * * /usr/bin/php ${WEB}/cron_alerts.php"

# ── Step 8: Restart Apache ─────────────────────────────────────
echo "[8/9] Restarting Apache (activates ossec group)..."
systemctl restart apache2
echo "  ✓ Apache restarted"

# ── Step 9: Run cron manually to test immediately ──────────────
echo "[9/9] Running cron NOW to test..."
echo ""
/usr/bin/php "$WEB/cron_alerts.php"
echo ""

echo "============================================"
echo " Verification"
echo "============================================"
echo ""
echo "Cron log:"
tail -5 /var/log/sentinel-cron.log 2>/dev/null || echo "(no log yet)"
echo ""
echo "DB alert count:"
mysql -u wazuh_user -pWazuhDB@2024! wazuh_dashboard \
  -e "SELECT COUNT(*) AS brute_force_alerts FROM brute_force_alerts; SELECT COUNT(*) AS blocked_ips FROM blocked_ips WHERE is_active=1;" 2>/dev/null || \
mysql -u wazuh_user -p'Wazuh@2024!' wazuh_dashboard \
  -e "SELECT COUNT(*) AS brute_force_alerts FROM brute_force_alerts; SELECT COUNT(*) AS blocked_ips FROM blocked_ips WHERE is_active=1;" 2>/dev/null
echo ""
echo "============================================"
echo " DONE! Open: http://$(hostname -I | awk '{print $1}')/wazuh-dashboard/"
echo "============================================"
